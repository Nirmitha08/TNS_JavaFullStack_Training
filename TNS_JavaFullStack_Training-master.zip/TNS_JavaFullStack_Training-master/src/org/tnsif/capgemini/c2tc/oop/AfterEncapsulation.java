package org.tnsif.capgemini.c2tc.oop;

class Human1
{
	private int age;
	private String name;
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		return age;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	
}
public class AfterEncapsulation {
	public static void main(String[] args) {
		Human1 obj=new Human1();
		obj.setAge(12);
		obj.setName("Hema");
		System.out.println(obj.getAge());
		System.out.println(obj.getName());
		
		obj.setAge(34);
		obj.setName("Anil");
		System.out.println(obj.getAge());
		System.out.println(obj.getName());
		
		
	}

}
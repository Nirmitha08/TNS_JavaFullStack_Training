package org.tnsif.capgemini.c2tc.oop;

class PaymentMethod
{
	void makePayment()
	{
		System.out.println("Processing payment");
	}
}

class CreditCard extends PaymentMethod
{
	void swipecard()
	{
		System.out.println("Swiping credit card");
	}
}

class Paypal extends PaymentMethod
{
	void loginToPaypal()
	{
		System.out.println("Logging into paypal");
	}
}

public class Instance2 {

	public static void main(String[] args) {
		PaymentMethod payment = new PaymentMethod();

		payment=new CreditCard();
		
		if(payment instanceof CreditCard)
		{
			CreditCard cc = (CreditCard) payment;
			cc.swipecard();
		}
		else if(payment instanceof  Paypal)
		{
			 Paypal  pp = (Paypal) payment;
			 pp.loginToPaypal();

		}

	}

}
package org.tnsif.capgemini.c2tc.final_keyword;

class calc
{
	public final void show()
	{
		//code implementation
		System.out.println("AI integration done by hema");
	}
	public void add(int a ,int b)
	{
		System.out.println(a+b);
	}
}
class Advcalc extends calc
{
	public void show()
	{
		
	}
	public void add(int a ,int b)
	{
		System.out.println("welcome");
	
	}
}
public class FinalMethod {

	public static void main(String[] args) {
		

	}

}